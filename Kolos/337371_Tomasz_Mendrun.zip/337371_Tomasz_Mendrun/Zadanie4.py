
for x in range(2,100,2):
	print(x)
	if x%3==0 and x%5==0:
		print("SykBzyk")
	elif x%3==0:
		print("Syk")
	elif x%5==0:
		print("Bzyk")
	
