K=(('król',{2:'królewna', 1:['córka','wróbel']},'5'),('żółw','pies'))
print(K[0][1][1][1])
